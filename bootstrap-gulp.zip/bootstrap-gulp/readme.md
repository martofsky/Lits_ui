# Setting up Gulp, Bower, Bootstrap Sass, & FontAwesome

This is a demo repo for the tutorial [Setting up Gulp, Bower, Bootstrap Sass, & FontAwesome](http://ericlbarnes.com/setting-gulp-bower-bootstrap-sass-fontawesome/).

## Installation

1. Clone this repo.
2. cd into the directory and run `npm install`
3. Run `gulp` and it will pull in all dependencies and compile.

